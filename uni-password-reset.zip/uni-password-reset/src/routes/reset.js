const express = require('express');
const db = require('../db');
const { generateToken, hashToken } = require('../services/token');
const { sendResetEmail } = require('../services/mailer');
const { setPassword } = require('../services/directory');
const { requestLimiter } = require('../middleware/rateLimit');

const router = express.Router();
const TOKEN_TTL = 15 * 60 * 1000; // 15 นาที

// ขั้นที่ 1: ขอลิงก์รีเซ็ต
router.post('/request', requestLimiter, async (req, res) => {
  // ตอบข้อความเดิมเสมอ เพื่อไม่ให้คนนอกเดาได้ว่ามีบัญชีนี้หรือไม่
  const GENERIC = { message: 'ถ้าข้อมูลถูกต้อง เราได้ส่งลิงก์ไปยังอีเมลสำรองของคุณแล้ว' };
  try {
    const { identifier, birth_date } = req.body;
    const user = db
      .prepare('SELECT * FROM users WHERE student_id = ? OR email = ?')
      .get(identifier, identifier);

    if (user && user.birth_date === birth_date) {
      // ยกเลิก token เก่าที่ยังไม่ถูกใช้
      db.prepare('UPDATE reset_tokens SET used_at = ? WHERE student_id = ? AND used_at IS NULL')
        .run(Date.now(), user.student_id);

      const raw = generateToken();
      db.prepare(
        'INSERT INTO reset_tokens (student_id, token_hash, expires_at, requested_ip) VALUES (?,?,?,?)'
      ).run(user.student_id, hashToken(raw), Date.now() + TOKEN_TTL, req.ip);

      await sendResetEmail(user.backup_email, `${process.env.BASE_URL}/reset.html?token=${raw}`);
    }
  } catch (err) {
    console.error('request error:', err.message);
  }
  res.json(GENERIC);
});

// ขั้นที่ 2: ตั้งรหัสผ่านใหม่
router.post('/confirm', (req, res) => {
  const { token, new_password } = req.body;

  if (!token || typeof new_password !== 'string' || new_password.length < 12) {
    return res.status(400).json({ message: 'รหัสผ่านต้องยาวอย่างน้อย 12 ตัวอักษร' });
  }

  const rec = db.prepare('SELECT * FROM reset_tokens WHERE token_hash = ?').get(hashToken(token));
  if (!rec || rec.used_at || rec.expires_at < Date.now()) {
    return res.status(400).json({ message: 'ลิงก์ไม่ถูกต้องหรือหมดอายุ' });
  }

  // "จอง" token ก่อน กันการกดซ้ำพร้อมกัน (ใช้ได้ครั้งเดียวจริงๆ)
  const claimed = db
    .prepare('UPDATE reset_tokens SET used_at = ? WHERE id = ? AND used_at IS NULL')
    .run(Date.now(), rec.id);
  if (claimed.changes !== 1) {
    return res.status(400).json({ message: 'ลิงก์ถูกใช้ไปแล้ว' });
  }

  const user = db.prepare('SELECT * FROM users WHERE student_id = ?').get(rec.student_id);
  setPassword(user.email, new_password)
    .then(() => res.json({ message: 'เปลี่ยนรหัสผ่านสำเร็จ' }))
    .catch(() => res.status(500).json({ message: 'เกิดข้อผิดพลาด กรุณาขอลิงก์ใหม่' }));
});

module.exports = router;
