# ระบบรีเซ็ตรหัสผ่านอีเมลมหาวิทยาลัย (ต้นแบบ)

Node.js + Express + SQLite + HTML ธรรมดา

## วิธีรัน
1. ติดตั้ง Node.js 18 ขึ้นไป
2. เปิดโฟลเดอร์นี้ใน VS Code แล้วเปิด Terminal
3. `npm install`
4. `npm start`
5. เปิด http://localhost:3000/forgot.html

## ทดสอบ
- รหัสนักศึกษา: `6400000001`
- วันเกิด: `2002-01-31`
- กดส่งลิงก์ แล้วดูลิงก์ `[DEV] ลิงก์รีเซ็ต...` ใน Terminal
- คัดลอกลิงก์ไปเปิดในเบราว์เซอร์ แล้วตั้งรหัสผ่านใหม่ (อย่างน้อย 12 ตัว)
- ลองเปิดลิงก์เดิมซ้ำ ควรใช้ไม่ได้

## โครงสร้าง
- `src/server.js`            จุดเริ่มโปรแกรม
- `src/db.js`                ฐานข้อมูล SQLite + ข้อมูลผู้ใช้ทดสอบ
- `src/routes/reset.js`      API: POST /api/reset/request และ /api/reset/confirm
- `src/services/token.js`    สร้างและ hash token
- `src/services/mailer.js`   ส่งอีเมล (ไม่ตั้ง SMTP = พิมพ์ลิงก์ใน Terminal)
- `src/services/directory.js` ตัวเปลี่ยนรหัสผ่านจริง (ตอนนี้เป็น mock — ต้องแก้ก่อนใช้จริง)
- `src/middleware/rateLimit.js` จำกัดคำขอ
- `public/`                  หน้าเว็บ

## ก่อนใช้งานจริง
- เชื่อม `directory.js` กับ Google Workspace / Microsoft 365 / LDAP
- ดึงข้อมูลผู้ใช้จากฐานข้อมูลของมหาวิทยาลัย แทนข้อมูลทดสอบใน `db.js`
- เพิ่ม CAPTCHA, OTP, audit log
- ใช้ HTTPS และขออนุมัติจากฝ่าย IT/Security
